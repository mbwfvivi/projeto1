var app = {
    // Application Constructor
    initialize: function() {
        this.bindEvents();
    },
    // Bind Event Listeners
    //
    // Bind any events that are required on startup. Common events are:
    // 'load', 'deviceready', 'offline', and 'online'.
    bindEvents: function() {
       },
    
      capturePhoto: function() {
        navigator.camera.getPicture(onSuccess, onFail, { 
        quality: 50,
    destinationType: Camera.DestinationType.DATA_URL,
saveToPhotpAlbum:true
     });

function onSuccess(imageData) {
    var image = document.getElementById('minhaimagem');
    image.style.display ="block";
    image.src = "data:image/jpeg;base64," + imageData;
}

function onFail(message) {
    alert('Failed because: ' + message);
}
    }}
    